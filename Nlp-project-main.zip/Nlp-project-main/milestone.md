## Dataset exploration 
squad dataset comes with context and answer start which tells you where the answer starts in this context
triviaQA is more dedicated for more trivia like questions

uses glove for embeddings as it is better for word to vec for the question and answer
